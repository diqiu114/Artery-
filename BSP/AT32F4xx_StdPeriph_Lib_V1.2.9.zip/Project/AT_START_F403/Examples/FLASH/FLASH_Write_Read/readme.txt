/**
  @page FLASH_Write_Read example
  
  @verbatim
  * File   : FLASH/FLASH_Write_Read/readme.txt 
  * Version: V1.2.9
  * Date   : 2021-01-15
  * Brief  : Description of the FLASH_Write_Read.
  ******************************************************************************
   @endverbatim

@par Example Description 

This demo is based on the AT-START-F403 board. 
In this demo, test buffer will be wiriten to flash and read from same address ,then compare them.  
if passed,LED2 ON,LED3 OFF;
if failed LED2 OFF,LED3 ON.

 */
