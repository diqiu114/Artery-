/**
  @page BKP_Tamper BKP Tamper example
  
  @verbatim
  * File   : BKP/Tamper/readme.txt 
  * Version: V1.2.9
  * Date   : 2021-01-15
  * Brief  : Description of the BKP Tamper example.
  ******************************************************************************
   @endverbatim

@par Example Description 

This example shows how to write/read data to/from Backup data registers and 
demonstrates the Temper pin(PC13) detection feature.
    
 */
 