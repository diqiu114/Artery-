/**
  ******************************************************************************
  * File   : CortexM4/FPU/readme.txt 
  * Version: V1.2.9
  * Date   : 2021-01-15
  * Brief  : cortex-m4 fpu
  ******************************************************************************
  * @Description
  * 
  *   This demo is based on the AT-START-F403 board,in this demo, test the FPU efficiency.
  * Using USART1 print the Results.  
  * 
  ******************************************************************************
  */

