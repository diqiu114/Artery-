/**
  ******************************************************************************
  * File   : CortexM4/BitBand/readme.txt 
  * Version: V1.2.9
  * Date   : 2021-01-15
  * Brief  : cortex-m4 bitband
  ******************************************************************************
  * @Description
  * 
  *   This demo is based on the AT-START-F403 board,in this demo,modify the variable
  * by its address and then read the address.If the variable is not the respect,LED4
  * flick.If no error,LED2,LED3 and LED4 turn over every 3s.  
  * 
  ******************************************************************************
  */ 

