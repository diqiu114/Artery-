/**
  **************************************************************************
  * File   : usart.h
  * Version: V1.2.9
  * Date   : 2021-01-15
  * Brief  : none
  **************************************************************************
  */
#ifndef __USART_H
#define __USART_H
#include "stdio.h"	
#include "sys.h" 

void Uart1_Init(u32 bound);
#endif


