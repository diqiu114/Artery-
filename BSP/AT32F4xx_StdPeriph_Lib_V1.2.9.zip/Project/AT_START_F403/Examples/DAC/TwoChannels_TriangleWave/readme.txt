/**
  **************************************************************************
  * File   : DAC/TwoChannels_TriangleWave/readme.txt
  * Version: V1.2.9
  * Date   : 2021-01-15
  * Brief  : Use DAC1/2 to generate triangle waveform.
  **************************************************************************
  */

  @Description
    This demo is based on the AT-START-F403 board,in this demo,PA4 PA5 output triangle waveform. 
    
